# Rocket Game: Mission Architect

A Turkish/English 2D space mission design and flight game built with Python and Pygame. Choose a NASA-inspired mission, design a spacecraft within its budget and engineering limits, then fly, scan objectives, and earn funds for better hardware.

> This is an independent educational game and is not affiliated with, endorsed by, or sponsored by NASA. Mission concepts are simplified for gameplay.

## Features

- Turkish and English interface
- Spacecraft design with budget, mass, power, delta-v, and communications telemetry
- Unlockable missions and hardware shop
- 2D flight, landing, scanning, and mission objectives
- Fullscreen toggle with `Esc`

## Requirements

- Python 3.10 or newer
- Pygame 2.5 or newer (2.x)

## Run

```bash
python -m pip install -r requirements.txt
python main.py
```

The game opens in fullscreen. Press `Esc` to switch between fullscreen and windowed mode. The game uses built-in shapes and system fonts; no external game assets are required.

## Controls

| Key | Action |
| --- | --- |
| `W` / `↑` | Thrust |
| `S` / `↓` | Brake |
| `A` / `←`, `D` / `→` | Rotate |
| Hold `E` | Scan an objective while landed |
| `Esc` | Toggle fullscreen |
| Mouse wheel / arrow keys | Scroll the shop |

## Project layout

```text
.
├── main.py
├── requirements.txt
├── .gitignore
└── README.md
```

## Notes

- Mission data and gameplay are contained in `main.py` for easy download and launch.
- Progress and purchased items reset when the game is restarted.
- NASA names are used only to describe the game's fictionalized, educational mission scenarios.
